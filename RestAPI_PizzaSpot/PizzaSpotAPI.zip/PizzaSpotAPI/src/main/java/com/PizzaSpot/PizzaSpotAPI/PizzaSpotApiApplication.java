package com.PizzaSpot.PizzaSpotAPI;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PizzaSpotApiApplication {

	public static void main(String[] args) {
		SpringApplication.run(PizzaSpotApiApplication.class, args);
	}

}
